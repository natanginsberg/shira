package com.damn.karaoke.phone;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.damn.karaoke.core.controller.KaraokeController;

import java.io.File;

public class SingActivity extends Activity {

    public static final String EXTRA_SONG = "EXTRA_SONG";
    @SuppressWarnings("SpellCheckingInspection")
    private KaraokeController mKaraokeKonroller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing);
        mKaraokeKonroller = new KaraokeController();
        mKaraokeKonroller.init(findViewById(R.id.root), R.id.lyrics, R.id.camera);
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        else {
            tryLoadSong();
        }
        if (checkCameraHardware(this)){
            Camera camera = getCameraInstance();

        };
    }

    /** A safe way to get an instance of the Camera object. */
    public static Camera getCameraInstance(){
        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
        }
        catch (Exception e){
            // Camera is not available (in use or does not exist)
        }
        return c; // returns null if camera is unavailable
    }

    /** Check if this device has a camera */
    private boolean checkCameraHardware(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
            // this device has a camera
            return true;
        } else {
            // no camera on this device
            return false;
        }
    }

    private void tryLoadSong() {
        String songFile = getIntent().getStringExtra(EXTRA_SONG);
        if(null != songFile)
            mKaraokeKonroller.load(new File(songFile));
        else
            finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            finish();
        else
            tryLoadSong();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mKaraokeKonroller.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mKaraokeKonroller.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mKaraokeKonroller.onStop();
    }

}
